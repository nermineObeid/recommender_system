<section class="footer">
    <div class="container text-center">
       <p>Designed By <a href="about.php">JANA</a></p>
    </div>
    </section>
</body>
</html>