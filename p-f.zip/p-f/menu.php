<?php include('connection.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MKM Online Shop</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!--navbar-->
    <section class="navbar">
    <div class="container">
        <div class="logo">
           <a href="<?php echo SITEURL; ?>customerhome.php">
           <img src="images/logo.png" alt="JANA" class="img-responsive">
           </a>
        </div>
        <div class="menu text-right">
        <ul>
             <li>
            <a href="<?php echo SITEURL; ?>about.php"><img src="https://img.icons8.com/nolan/64/about-us-male.png" title="ABOUT US" width="50px" height="50px"/></a>
            </li>
        <li>
            <a href="<?php echo SITEURL; ?>customerhome.php"  ><img src="https://img.icons8.com/nolan/64/home-page.png" title="HOME" width="50px" height="50px"/></a>
         

            
            </li>    
        <li>
            <a href="<?php echo SITEURL; ?>show_type.php"><img src="https://img.icons8.com/nolan/64/used-product.png" title="CATEGORIES" width="50px" height="50px"/></a>
            </li>  
        <li>
            <a href="<?php echo SITEURL; ?>checkgroupbuy.php"><img src="images/mechant.png" title="comfirm buy" width="50px" height="50px"/></a>
            </li>
       

       
            
   
          <li>
            <a href="<?php echo SITEURL; ?>chat1.php">
                <img src="images/massenger.png" title="messenger" width="50px" height="50px"/>
            
            </a>
        
        </li>
            <li>
            <a href="<?php echo SITEURL; ?>checkbalance.php">
                <img src="images/amou.png" title="amount" width="50px" height="50px"/>
               </a>
         
        
        </li>
             <li>
            <a href="<?php echo SITEURL; ?>profile.php?id=<?php echo  $id=$_SESSION['id']; ?>">
               
             <img src="images/<?php $ima=$_SESSION['image']; echo $ima;?>" title="My Profile" style=" border-radius:20px;width: 50px ; height: 50px;" />
         </a>
         
                   </li>
                      <li>
                 
                  <a href="<?php echo SITEURL; ?>track.php">
                <img src="images/RR.png" title="track your orders" width="39px" height="43px"/>
            
            </a>
        
      
        </ul>
        </div>
        <div class="clearfix"></div>
    </div>
    </section>